package com.twostringsum.spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SumOfTwoLargeNumbersApplication  {

	
	public static void main(String[] args) {
		SpringApplication.run(SumOfTwoLargeNumbersApplication.class, args);
	}

	
}
