# TwoStringSum
## What is TwoStringSum?
A Web App that teaches students to learn the steps to plus two large numbers without using the calculator.

**Languages**: Java, JavaScript, Html/Css <br />
**The technologies used**: Applied Spring Boot with Thymeleaf, Bootstrap, integrated AJAX for asynchronous server calls and set the Session Tracking mechanism to differentiate user-agent requests. 
 
![twostringssum](https://user-images.githubusercontent.com/31901141/42988708-3c070b14-8bc3-11e8-8641-14fc95848ade.png)

